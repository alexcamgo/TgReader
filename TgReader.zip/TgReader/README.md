# TG Reader — text-to-speech for Telegram channels

Two ways to use it:
1. **Public channels:** type the channel name (`durov`, `@durov` or `t.me/durov`), tap Load, tap any post. It reads that post and keeps going through the newer ones.
2. **Any message (incl. private channels/chats):** in Telegram, long-press a message → Share → "TG Reader". It reads it aloud immediately.

Controls: ⏮ ▶/⏹ ⏭, speed slider (0.5x–3x), voice language picker. Links are skipped when reading.

## Get the APK
**Without installing anything:** push this folder to a GitHub repo → Actions tab → "Build APK" run → download `tg-reader-apk` → install on phone (allow "install unknown apps").

**With Android Studio:** File → Open → this folder → Run ▶.

## Notes
- Channel loading uses Telegram's public web preview (`t.me/s/<channel>`), so it only works for public channels with preview enabled. No login or API keys.
- Voice quality depends on your phone's TTS engine. For non-English channels, install that language's voice in Settings → Text-to-speech.
